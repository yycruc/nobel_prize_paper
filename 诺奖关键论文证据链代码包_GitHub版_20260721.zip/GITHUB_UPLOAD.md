# GitHub 发布与复现说明

## 发布者操作

1. 将本文件夹改名为简短英文名，例如 `nobel-key-paper-evidence`。
2. 在 GitHub 新建空仓库，不要自动添加 README、`.gitignore` 或 License。
3. 在本文件夹打开 PowerShell，执行：

```powershell
git init
git add .
git commit -m "Initial reproducible research pipeline"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

4. 在 GitHub 仓库设置中确认 README 已显示，并检查没有上传原始 PDF、HTML、API 缓存或个人信息。

## 使用者操作

```powershell
git clone https://github.com/USERNAME/REPOSITORY.git
cd REPOSITORY
py -3.11 -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python preflight.py
```

随后按照 `RUNBOOK.md` 先运行验证流程，再依次执行 baseline、targets、fetch、extract、match 和 review。人工复核完成后，最后运行 analysis 阶段。

## 能否一键运行

不能把“脚本执行成功”与“研究结论已经可信”混为一谈。网页下载和元数据匹配可以自动化，但官方证据与候选论文之间的最终对应关系需要人工确认。因此，本仓库提供的是可复现的研究流程，而不是无人值守的一键结论生成器。
